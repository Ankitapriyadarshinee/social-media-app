from django.shortcuts import render
from django.http import HttpResponse


def index(request):
    return render(request,"index.html")

def notifications(request):
    return render(request,'notifications.html' )

def messages(request):
     return render(request, 'messages.html')

def friends(request):
    return render(request, 'friends.html')

def groups(request):
    return render(request, 'groups.html')

def favorite(request):
    return render(request, 'favorite.html')

def events(request):
    return render(request, 'events.html')

def live(request):
    return render(request, 'live-chat.html')

def birthday(request):
    return render(request, 'birthday.html')
def video(request):
    return render(request, 'video.html')
def weather(request):
    return render(request, 'weather.html')

def marketplace(request):
    return render(request, 'marketplace.html')

def login(request):
    return render(request, 'login.html')

def register(request):
    return render(request, 'register.html')

def myprofile(request):
    return render(request, 'my-profile.html')

def setting(request):
    return render(request, 'setting.html')

def privacy(request):
    return render(request, 'privacy.html')

def helpandsupport(request):
    return render(request, 'help-and-support.html')