from django.db import models

# Create your models here.
class service(models.Model):
    ser_icon=models.CharField(max_length=50)
    ser_titile=models.CharField(max_length=50)
    ser_des=models.TextField()

