from django.contrib import admin

# Register your models here.

# class serviceAdmin(admin.ModelAdmin):
#     list_display =('ser_icon' ,'ser_title','ser_des')

#     admin.site.register( )